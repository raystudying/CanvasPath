# -*- coding=utf8 -*-
# 导入Flask库
from flask import Flask
from flask import request
from flask import render_template,redirect, url_for

# 导入SQLITE3库
import sqlite3


app = Flask(__name__)


conn = sqlite3.connect('canvas_path.sqlite',check_same_thread=False)
cur = conn.cursor()

def get_Table_Data(table):
    sqlite3.connect('canvas_path.sqlite',check_same_thread=False)
    cur = conn.cursor()
    res = cur.execute("select * from " + table)
    res = cur.fetchall()

    conn.commit()

    return res

# show the login function
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('login.html')

# login test
@app.route('/login', methods=['POST', 'GET'])
def login():
    error = None
    if request.method == 'POST':
        loc_email = request.form['username']
        loc_pass = request.form['password']
        global email
        global password
        email = loc_email
        password = loc_pass
        cur.execute("select * from student where email='"+email+"' and password='"+password+"';")
        result_student = cur.fetchall()
        cur.execute("select * from professor where email='"+email+"' and password='"+password+"';")
        result_professor = cur.fetchall()

        print(result_student)
        print(result_professor)

        if not result_student and email != 'admin@lionstate.edu' and result_professor:
            print('in professor')
            return redirect("/teacher_index")
        elif not result_professor and email != 'admin@lionstate.edu' and result_student:
            print("in student")
            return redirect("/student_index")
        elif email == 'admin@lionstate.edu' and password == '123456':
            print("in admin")
            return redirect("/admin_index")
        else:
            print('log in fail')
            return render_template('login.html', error = 'wrong password')
    return render_template('login.html', error = error)



@app.route('/student_index', methods=['GET'])
def student_index():
    return render_template('student_index.html')

@app.route('/teacher_index', methods=['GET'])
def teacher_index():
    return render_template('teacher_index.html')

@app.route('/admin_index', methods=['GET'])
def admin_index():
    return render_template('admin_index.html')




@app.route('/Yourcourse', methods=['GET'])
def Yourcourse():

    cur.execute("select teaching from professor where email='" + email + "';")
    data = cur.fetchall()

    posts = []
    for value in data:
        dict_data = {}
        dict_data['a'] = value[0]
        global teaching
        teaching =dict_data['a']
        posts.append(dict_data)
    # print posts
    return render_template('teacher.html', posts=posts)



@app.route('/create', methods=['POST', 'GET'])
def create():
    error = None
    if request.method == 'POST':
        course = request.form['course']
        section = request.form['section']
        assignment = request.form['hw_detail']
        hw_no = request.form['hw_no']
        if "create" in request.form:
            if teaching == course:
                cur.execute('INSERT INTO homework (course_id,sec_no,hw_no,hw_detail) VALUES (?,?,?,?)',
                         [course, section, hw_no, assignment])
                conn.commit()
                print('create successful')
                return render_template('create.html', message="create successful")
        else:
                print('not your class')
                return render_template('create.html', message="not your class")
    return render_template('create.html', error=error)




@app.route('/grade', methods=['POST', 'GET'])
def grade():
    error = None
    if request.method == 'POST':
        course = request.form['course']
        section = request.form['section']
        email = request.form['email']
        hw_no = request.form['hw_no']
        grade = request.fom['grade']
        if "gradesubmit" in request.form:
            if teaching == course:
                cur.execute('INSERT INTO homework (course_id,sec_no,email,hw_no,grade) VALUES (?,?,?,?,?)',
                         [course, section, email,hw_no, grade])
                conn.commit()
                print('grade successful')
                return render_template('grade.html', message="grade successful")
        else:
                print('not your class')
                return render_template('grade.html', message="not your class")
    return render_template('grade.html', error=error)


@app.route('/admin',methods=['POST','GET'])
def admin():
    if request.method =='POST':
        course = request.form['course']
        section = request.form['section']
        professor = request.form['professor']
        student = request.form['student']
        if "add" in request.form:
            cur.execute('INSERT INTO course (course_id) VALUES (?)',[course])
            conn.commit()
            print('insert successful')
            return render_template('admin.html',message = "insert successful")
        elif "remove" in request.form:
            cur.execute('DELETE FROM course WHERE course_id = '"+course"';')
            conn.commit()
            print('delete successful')
            return render_template('admin.html')
        elif "enroll" in request.form:
            cur.execute('INSERT INTO enrolls (student_email, course_id, section_no) VALUES (?,?,?)',(student,course,section))
            conn.commit()
            print('enroll successful')
            return render_template('admin.html',message = 'enroll successful')
        elif "assign" in request.form:
            cur.execute('INSERT INTO sections (prof_team_id, course_id, sec_no) VALUES (?,?,?)',
                        [professor, course, section])
            conn.commit()
            print('assign successful')
            return render_template('admin.html', message='assign successful')

    return render_template('admin.html')

@app.route('/Checkinfo', methods=['GET'])
def Checkinfo():
    # 调用数据库函数，获取数据
    cur.execute("select * from courseinfo where email='" + email + "';")
    data = cur.fetchall()
    # 用列表的格式存放全部数据
    posts = []
    for value in data:
        dict_data = {}
        dict_data['a'] = value[1]
        dict_data['b'] = value[2]
        dict_data['c'] = value[3]
        dict_data['d'] = value[4]
        dict_data['e'] = value[5]
        posts.append(dict_data)
    # print posts
    return render_template('student.html', posts=posts)

# 显示课程的函数页面
@app.route('/Course1', methods=['GET'])
def Course1():
    # 调用数据库函数，获取数据
    cur.execute("select * from course1 where email='" + email + "';")
    data = cur.fetchall()
    # 用列表的格式存放全部数据
    posts = []
    for value in data:
        dict_data = {}
        dict_data['a'] = value[1]
        dict_data['b'] = value[2]
        dict_data['c'] = value[3]
        dict_data['d'] = value[4]
        dict_data['e'] = value[5]
        dict_data['f'] = value[6]
        dict_data['g'] = value[7]
        dict_data['h'] = value[8]
        dict_data['i'] = value[9]
        posts.append(dict_data)
    # print posts
    return render_template('courseinfo.html', posts=posts)

# 显示专业的函数页面
@app.route('/Course2', methods=['GET'])
def Course2():
    cur.execute("select * from course2 where email='" + email + "';")
    data = cur.fetchall()
    # 用列表的格式存放全部数据
    posts = []
    for value in data:
        dict_data = {}
        dict_data['a'] = value[1]
        dict_data['b'] = value[2]
        dict_data['c'] = value[3]
        dict_data['d'] = value[4]
        dict_data['e'] = value[5]
        dict_data['f'] = value[6]
        dict_data['g'] = value[7]
        dict_data['h'] = value[8]
        dict_data['i'] = value[9]
        posts.append(dict_data)
    # print posts
    return render_template('courseinfo.html', posts=posts)


@app.route('/Course3', methods=['GET'])
def Course3():
    cur.execute("select * from course3 where email='" + email + "';")
    data = cur.fetchall()
    # 用列表的格式存放全部数据
    posts = []
    for value in data:
        dict_data = {}
        dict_data['a'] = value[1]
        dict_data['b'] = value[2]
        dict_data['c'] = value[3]
        dict_data['d'] = value[4]
        dict_data['e'] = value[5]
        dict_data['f'] = value[6]
        dict_data['g'] = value[7]
        dict_data['h'] = value[8]
        dict_data['i'] = value[9]
        posts.append(dict_data)
    # print posts
    return render_template('courseinfo.html', posts=posts)

@app.route('/Changepwd', methods=['POST', 'GET'])
def Changepwd():
    if request.method == 'POST':
        newpwd = request.form['newpwd']
        oldpwd = request.form['oldpwd']
        cur.execute("Update student SET password ='"+newpwd+"'' Where password ='"+oldpwd+"';")
        conn.commit()
        print('change password success')
    return render_template('Changepwd.html')



if __name__ == '__main__':
    # app.debug = True
    app.run()